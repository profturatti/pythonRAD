#!/bin/bash

# Criar o ambiente virtual
python3 -m venv venv

# Verifica se o comando anterior foi bem-sucedido
if [ $? -ne 0 ]; then
    echo "Falha ao criar o ambiente virtual."
    exit 1
fi

# Ativar o ambiente virtual
source venv/bin/activate

# Verifica se a ativação foi bem-sucedida
if [ $? -ne 0 ]; then
    echo "Falha ao ativar o ambiente virtual."
    exit 1
fi

# Instalar as dependências
pip3 install -r requirements.txt

# Verifica se a instalação foi bem-sucedida
if [ $? -ne 0 ]; then
    echo "Falha ao instalar os pacotes."
    exit 1
fi

echo "Ambiente virtual criado e pacotes instalados com sucesso."