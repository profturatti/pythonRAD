from flask import Flask, request, jsonify, render_template, redirect, url_for
from flask_cors import CORS
import sqlite3
from datetime import datetime

app = Flask(__name__)
# a linha a seguir permite testes em localhost (same-origin)
CORS(app)  # <-- enable CORS for all routes
# para restringir somente para um host de testes
#CORS(app, resources={r"/api/*": {"origins": "http://localhost:3000"}})

DB = 'contactlist.db'

# Criação da tabela se não existir
def init_db():
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            surname TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            birthday TEXT NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api', methods=['POST'])
def add_user():
    data = request.get_json()
    try:
        birthday = datetime.strptime(data.get('birthday'), '%d/%m/%Y')
    except ValueError:
        return jsonify({'error': 'Formato de data inválido'}), 400

    try:
        conn = sqlite3.connect(DB)
        c = conn.cursor()
        c.execute('''
            INSERT INTO users (name, surname, email, birthday)
            VALUES (?, ?, ?, ?)
        ''', (data.get('name'), data.get('surname'), data.get('email'), data.get('birthday')))
        conn.commit()
        conn.close()
        return jsonify({'message': 'Usuário adicionado com sucesso'}), 201
    except sqlite3.IntegrityError:
        return jsonify({'error': 'Email já cadastrado'}), 400

@app.route('/api', methods=['GET'])
def block_api_get():
    # Usuário tentou acessar /api diretamente no navegador
    return render_template('error_404.html', message="Rota /api não disponível diretamente."), 404

@app.route('/api/users', methods=['GET'])
def list_users():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('SELECT * FROM users')
    users = [dict(row) for row in c.fetchall()]
    conn.close()
    return jsonify(users)

@app.route('/users')
def list_users_html():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    c.execute('SELECT * FROM users')
    users = c.fetchall()
    conn.close()
    return render_template('users.html', users=users)

@app.route('/delete/<int:user_id>', methods=['POST'])
def delete_user(user_id):
    conn = sqlite3.connect(DB)
    c = conn.cursor()
    c.execute('DELETE FROM users WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('list_users_html'))

@app.route('/edit/<int:user_id>', methods=['GET', 'POST'])
def edit_user(user_id):
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    if request.method == 'POST':
        name = request.form['name']
        surname = request.form['surname']
        email = request.form['email']
        birthday = request.form['birthday']  # YYYY-MM-DD do input[type="date"]

        try:
            # Converter para DD/MM/AAAA antes de salvar no banco
            dt = datetime.strptime(birthday, '%Y-%m-%d')
            birthday_str = dt.strftime('%d/%m/%Y')

            c.execute('''
                UPDATE users
                SET name = ?, surname = ?, email = ?, birthday = ?
                WHERE id = ?
            ''', (name, surname, email, birthday_str, user_id))
            conn.commit()
            conn.close()
            return redirect(url_for('list_users_html'))
        except ValueError:
            return "Data inválida", 400

    else:
        c.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        user = c.fetchone()
        conn.close()

        if user:
            # Converter DD/MM/AAAA → AAAA-MM-DD para preencher input[type="date"]
            birthday_str = user['birthday']
            try:
                birthday_iso = datetime.strptime(birthday_str, '%d/%m/%Y').strftime('%Y-%m-%d')
            except ValueError:
                birthday_iso = ''  # Se tiver problema de formatação
            return render_template('edit_user.html', user=user, birthday_iso=birthday_iso)
        else:
            return "Usuário não encontrado", 404

@app.errorhandler(404)
def not_found(e):
    return render_template("error_404.html", message="Página não encontrada."), 404


if __name__ == '__main__':
    init_db()
    app.run(port=3000, debug=True)

