# Aplicação Python Flask REST API com SQLite e interface para testes

- API REST (usa métodos HTTP: GET, POST, PUT e DELETE)
- SQLite para armazenamento de dados
- Interface para testes

Neste projeto além do `Flask` foi usado o `Flask-cors` para permitir 
testes num mesmo ambiente, ou seja, onde front-end e back-end funcionam
no mesmo IP, com rotas diferentes.

## Requisitos:

- Python 3.13 ou mais recente
- 15 MB de espaço em disco


## Como preparar o ambiente:

No Linux, execute o script `setup_env.sh`

No Windows, execute o `setup_env.bat`

Para preparar o ambiente virtual (venv) e então iniciar a aplicação

 python app.py

A interface estará disponível no navegador através do endereço:

 http://127.0.0.1:3000

## O que é uma API REST?

Uma API REST (Representational State Transfer API) é um estilo de arquitetura para a construção de interfaces de programação de aplicações (APIs) que utilizam requisições HTTP para acessar e manipular dados. Ela segue um conjunto de princípios, incluindo arquitetura cliente-servidor, comunicação sem estado e capacidade de cache, para garantir uma comunicação eficiente e confiável entre sistemas.

### Principais Características das APIs REST:

`Arquitetura Cliente-Servidor:`
A API opera em um modelo cliente-servidor, em que o cliente (por exemplo, um aplicativo) envia requisições ao servidor, e o servidor responde com os dados solicitados.

`Sem estado:`
Cada requisição do cliente para o servidor deve conter todas as informações necessárias para atendê-la, pois nenhum estado de sessão é mantido no servidor.

`Cache:`
As respostas do servidor podem ser armazenadas em cache para melhorar o desempenho, permitindo que os clientes recuperem dados mais rapidamente em requisições subsequentes.

`Interface Uniforme:`
As APIs REST utilizam uma interface padrão, normalmente utilizando métodos HTTP (GET, POST, PUT, DELETE) para executar operações em recursos.

`Sistema em Camadas:`
As APIs REST podem ser divididas em camadas, permitindo a adição de componentes intermediários, como balanceadores de carga ou serviços de segurança, sem afetar diretamente o cliente ou o servidor.

`Código sob Demanda (Opcional):`
Uma API REST pode, opcionalmente, enviar código executável (por exemplo, JavaScript) do servidor para o cliente, a fim de estender a funcionalidade do cliente.

### Como as APIs REST Funcionam:

1. O cliente envia uma solicitação:
O cliente (por exemplo, um aplicativo móvel ou navegador da web) envia uma solicitação ao servidor usando uma URL, que identifica o recurso que está sendo acessado.

2. O servidor processa a solicitação:
O servidor recebe a solicitação e, com base no método HTTP utilizado (GET, POST, PUT, DELETE), executa a ação correspondente no recurso.

3. O servidor envia uma resposta:
O servidor responde ao cliente com os dados solicitados, normalmente em um formato como JSON ou XML.

### Benefícios do uso de APIs REST:

`Flexibilidade:`
As APIs REST podem ser construídas com diversas linguagens de programação e formatos de dados, de acordo com a IBM.

`Escalabilidade:`
A arquitetura cliente-servidor torna as APIs REST altamente escaláveis, permitindo que lidem com grandes volumes de solicitações.

`Interoperabilidade:`
As APIs REST fornecem uma maneira padronizada para os aplicativos interagirem entre si, permitindo a interoperabilidade.

`Eficiência:`
A ausência de estado e a capacidade de armazenamento em cache contribuem para a comunicação eficiente e a utilização de recursos.

### Conclusão:

Essencialmente, as APIs REST fornecem uma maneira simples, flexível e eficiente para diferentes sistemas se comunicarem e trocarem dados pela internet. Elas são amplamente utilizadas no desenvolvimento de serviços web e em arquiteturas de microsserviços.

## O que é CORS?

CORS significa Cross-Origin Resource Sharing (Compartilhamento de Recursos entre Origens). É um mecanismo que permite que uma página da web acesse recursos de um domínio diferente daquele que a serviu. Isso é crucial para o desenvolvimento web moderno, permitindo que aplicativos interajam com APIs e serviços externos, mantendo a segurança.

Em termos mais simples: imagine uma página da web (de um site, vamos chamá-lo de "site A") que deseja obter dados de outro site (site B). Por padrão, um navegador bloqueará essa solicitação devido à Política de Mesma Origem. O CORS fornece uma maneira para o site B permitir (ou negar) explicitamente o acesso do site A aos seus recursos.

### Como funciona:

1. Solicitação de Pré-voo:
Quando um navegador faz uma solicitação de pré-voo de origem cruzada, ele primeiro envia uma solicitação de "pré-voo" (uma solicitação OPTIONS) ao servidor.

2. Resposta do Servidor:
O servidor responde à solicitação de pré-voo com um conjunto de cabeçalhos CORS.

3. Verificação do Navegador:
O navegador verifica esses cabeçalhos CORS para ver se a solicitação de origem cruzada é permitida. Em caso afirmativo, o navegador envia a solicitação.

4. Acesso a Recursos:
Se a solicitação for permitida, o servidor pode então enviar o recurso solicitado de volta ao navegador, que pode então ser usado na página web.

### Principais benefícios do CORS:

`Segurança:`
Permite que desenvolvedores web controlem quais domínios podem acessar seus recursos, impedindo acessos não autorizados.

`Flexibilidade:`
Permite a criação de aplicações web mais complexas que podem interagir com diversos serviços externos.

`Desenvolvimento Web Moderno:`
O CORS é uma parte fundamental de como as aplicações web modernas são construídas, permitindo o uso de APIs e outros recursos de origem cruzada.
